-- Copyright (c) 2020-2021 hoob3rt
-- MIT license, see LICENSE for more details.
local function progress()
  return '%3p%%'
end

return progress
