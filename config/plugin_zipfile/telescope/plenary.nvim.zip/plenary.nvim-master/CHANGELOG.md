## Pre-Alpha
- Change the keys in tables returned by functions in the `plenary.window.float` module:
    - `buf` -> `bufnr`
    - `minor_buf` -> `minor_bufnr`
    - `border_buf` -> `border_bufnr`
    - `win` -> `win_id`
    - `minor_win` -> `minor_win_id`
