# tflint

## Installing TFLint plugins

To install TFLint plugins, using the same installation of TFLint as nvim-lsp-installer, you may run the `:TFLintInit`
command. This command assumes that:

1. there exists a `.tflint.hcl` file in neovim's current working directory.
1. you've called `server:setup(opts)` for `tflint`
