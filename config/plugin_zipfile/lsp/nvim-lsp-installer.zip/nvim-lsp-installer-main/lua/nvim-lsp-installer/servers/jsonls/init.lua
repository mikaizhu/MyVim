return require "nvim-lsp-installer.servers.vscode-langservers-extracted" { "json" }
