if vim.filetype then
  vim.filetype.add({
    extension = {
      org = 'org',
      org_archive = 'org',
    },
  })
end
