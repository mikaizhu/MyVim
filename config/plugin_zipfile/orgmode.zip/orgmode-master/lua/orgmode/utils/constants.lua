return {
  default_offset_encoding = 'utf-16',
}
