struct Foo;

impl Foo {
    fn foo() -> i32 {
        1
    }
}
