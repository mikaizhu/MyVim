#include <iostream>
#include <cstdlib>
//    ^ include
//       ^ string

auto main( int argc, char** argv ) -> int
      //       ^ parameter
      //    ^ type 
      //    ^ TSType 
      //                  ^ operator
{
    std::cout << "Hello world!" << std::endl;
    
    return EXIT_SUCCESS;
    // ^ keyword.return
    //      ^ constant
}
